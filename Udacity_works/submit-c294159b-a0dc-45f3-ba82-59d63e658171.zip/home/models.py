from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)
db = SQLAlchemy()
migrate = Migrate(app, db)

class Venue(db.Model):
    __tablename__ = 'Venue'

    id = db.Column(Integer, primary_key=True)
    name = db.Column(String, nullable=False)
    genres = db.Column(ARRAY(String()), nullable=False)
    address = db.Column(String(120), nullable=False)
    city = db.Column(String(120), nullable=False)
    state = db.Column(String(120), nullable=False)
    phone = db.Column(String(120), nullable=False)
    website = db.Column(String(120))
    facebook_link = db.Column(String())
    seeking_talent = db.Column(Boolean, default=False)
    seeking_description = db.Column(String())
    image_link = db.Column(String(500), nullable=False)

    def __repr__(self):
        return f'<Venue {self.name, self.address, self.genres, self.shows}>'


class Artist(db.Model):
    __tablename__ = 'Artist'

    id = db.Column(Integer, primary_key=True)
    name = db.Column(String, nullable=False)
    genres = db.Column(ARRAY(String()), nullable=False)
    city = db.Column(String(120), nullable=False)
    state = db.Column(String(120), nullable=False)
    phone = db.Column(String(120), nullable=False)
    website = db.Column(String(120))
    facebook_link = db.Column(String())
    seeking_venue = db.Column(Boolean, default=False)
    seeking_description = db.Column(String())
    image_link = db.Column(String(500), nullable=False)

    def __repr__(self):
        return f'<Artist {self.id, self.name, self.genres, self.shows}>'


class Show(db.Model):
    __tablename__ = 'Show'

    id = db.Column(Integer, primary_key=True)
    venue_id = db.Column(Integer, ForeignKey(
        'Venue.id', onupdate='CASCADE', ondelete='CASCADE'), nullable=False)
    artist_id = db.Column(Integer, ForeignKey(
        'Artist.id', onupdate='CASCADE', ondelete='CASCADE'), nullable=False)
    start_time = db.Column(DateTime, nullable=False, default=datetime.utcnow())

    venue = db.relationship('Venue', backref=db.backref('shows', lazy=True))
    artist = db.relationship('Artist', backref=db.backref('shows', lazy=True))

    def __repr__(self):
        return f'<Show {self.id, self.start_time, self.artist}>'


# Seed data
artist1 = {
    "id": 4,
    "name": "PSquare",
    "genres": ["HipUp"],
    "city": "Ikeja",
    "state": "Lagos",
    "phone": "08078965437",
    "website": "https://www.psquare.com",
    "facebook_link": "https://www.facebook.com/PSquare",
    "seeking_venue": True,
    "seeking_description": "Looking for shows to perform at in Lagos!",
    "image_link": "https://images.unsplash.com/photo-1549213783-8284d0336c4f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=300&q=80",
}
artist2 = {
    "id": 5,
    "name": "Flavour",
    "genres": ["Jazz"],
    "city": "Nsukka",
    "state": "Enugu",
    "phone": "09087654245",
    "facebook_link": "https://www.facebook.com/flavour",
    "website": None,
    "seeking_venue": False,
    "seeking_description": None,
    "image_link": "https://images.unsplash.com/photo-1495223153807-b916f75de8c5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80"
}
artist3 = {
    "id": 6,
    "name": "Portable",
    "genres": ["Jazz", "Classical"],
    "city": "Abuja",
    "state": "FCT",
    "phone": "07098678954",
    "facebook_link": "https://www.facebook.com/portable",
    "website": None,
    "seeking_venue": False,
    "seeking_description": None,
    "image_link": "https://images.unsplash.com/photo-1558369981-f9ca78462e61?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=794&q=80"
}


venue1 = {
    "id": 1,
    "name": "DE-Angels",
    "genres": ["Jazz", "Reggae", "Swing", "Classical", "Folk"],
    "address": "Owerri, Imo State",
    "city": "Owerri",
    "state": "Imo",
    "phone": "09087986754",
    "website": "https://www.deangels.com",
    "facebook_link": "https://www.facebook.com/Deangels",
    "seeking_talent": True,
    "seeking_description": "We are on the lookout for a local artist to play every weeks. Please call us.",
    "image_link": "https://images.unsplash.com/photo-1543900694-133f37abaaa5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60"
}
venue2 = {
    "id": 2,
    "name": "Orange Glooves",
    "genres": ["Classical", "R&B", "Hip-Hop"],
    "address": "33 Obj street",
    "city": "Onitsha",
    "state": "Anambra",
    "phone": "09078695432",
    "website": "https://www.orangeglooves.com",
    "facebook_link": "https://www.facebook.com/orange",
    "seeking_talent": False,
    "seeking_description": None,
    "image_link": "https://images.unsplash.com/photo-1497032205916-ac775f0649ae?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80"
}
venue3 = {
    "id": 3,
    "name": "Rockview",
    "genres":  ["Rock n Roll", "Jazz", "Classical", "Folk"],
    "address": "GOVT House Arena",
    "city": "Aba",
    "state": "Abia",
    "phone": "08098765898",
    "website": "https://www.rockview.com",
    "facebook_link": "https://www.facebook.com/Rockview",
    "seeking_talent": False,
    "seeking_description": None,
    "image_link": "https://images.unsplash.com/photo-1485686531765-ba63b07845a7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=747&q=80"
}


show1 = {
    "id": 1,
    "venue_id": 1,
    "artist_id": 4,
    "start_time": "2022-06-12T21:30:00.000Z"
}

show2 = {
    "id": 2,
    "venue_id": 3,
    "artist_id": 5,
    "start_time": "2022-06-15T23:00:00.000Z"
}

show3 = {
    "id": 3,
    "venue_id": 3,
    "artist_id": 6,
    "start_time": "2022-06-18T20:00:00.000Z"
}

show4 = {
    "id": 4,
    "venue_id": 3,
    "artist_id": 6,
    "start_time": "2022-06-21T20:00:00.000Z"
}

show5 = {
    "id": 5,
    "venue_id": 3,
    "artist_id": 6,
    "start_time": "2022-06-24T20:00:00.000Z"
}