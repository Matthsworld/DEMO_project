import os
from math import ceil
from sys import exc_info, path
from flask import Flask, request, abort, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import random

from models import setup_db, Question, Category

QUESTIONS_PER_PAGE = 10

def paginate_outcome(outcome):
    page = request.args.get('page', 1, int)
    start = (page - 1) * QUESTIONS_PER_PAGE
    end = start + QUESTIONS_PER_PAGE

    return outcome[start:end]


def collect_categories():
    categories = Category.query.all()
    schemed_categories = [category.format() for category in categories]
    return schemed_categories


def collect_questions():
    questions = Question.query.all()
    schemed_questions = [question.format() for question in questions]
    return schemed_questions


def collect_questions_and_filter_by_category(category_id):
    questions = Question.query.filter(
        Question.category == str(category_id)).all()
    schemed_questions = [category.format() for category in questions]
    return schemed_questions


def manage_path_parameters_validation(parameters):
    try:
        int(parameters)
        pass

    except Exception as EXP:
        print(EXP)
        abort(400)


def create_app(test_config=None):
    # create and configure the app
    app = Flask(__name__)
    setup_db(app)

    '''
    @TODO: Set up CORS. Allow '*' for origins.
    Delete the sample route after completing the TODOs
    '''
    CORS(app)

    # '''
    # @TODO: Use the after_request decorator to set Access-Control-Allow
    # '''
    @app.after_request
    def program_access_control_headers(response):
        response.headers.add('Access-Control-Allow-Headers',
                             'Content-Type,Authorization,true')
        response.headers.add('Access-Control-Allow-Methods',
                             'GET,POST,PATCH,DELETE,OPTIONS')
        return response

    @app.route('/')
    def fetch_index():
        return redirect(url_for('fetch_questions'))

    @app.route('/categories')
    def fetch_categories():
        try:
            schemed_categories = collect_categories()

            return jsonify({
                'success': True,
                'categories': schemed_categories
            })

        except Exception as EXP:
            print(EXP)

    @app.route('/questions')
    def fetch_questions():
        try:
            schemed_questions = collect_questions()
            paginated_questions = paginate_outcome(schemed_questions)

            if request.args.get('page', 1, int) > ceil(
                    len(schemed_questions)/QUESTIONS_PER_PAGE):
                return manage_error_404('Range Exceeded!')

            return jsonify({
                'success': True,
                'questions': paginated_questions,
                'total_questions': len(schemed_questions),
                'categories': collect_categories(),
                'current_categories': None
            })

        except Exception as EXP:
            print(exc_info)
            abort(422)

    @app.route('/questions/<int:question_id>', methods=['DELETE'])
    def wipe_question(question_id):
        try:
            question = Question.query.filter(
                Question.id == question_id).one_or_none()
            question.delete()

            return jsonify({
                'success': True,
                'deleted': question_id
            })
        except Exception as EXP:
            print(EXP)
            abort(422)

    @app.route('/questions', methods=['POST'])
    def generate_question():
        body = request.get_json()

        search_term = body.get('searchTerm', None)

        if search_term:
            try:
                questions = Question.query.filter(
                    Question.question.ilike(f'%{search_term}%')).all()
                schemed_questions = [question.format()
                                      for question in questions]
                paginated_questions = paginate_outcome(schemed_questions)

                return jsonify({
                    'success': True,
                    'questions': paginated_questions,
                    'total_questions': len(schemed_questions),
                    'current_category': None
                })

            except Exception as EXP:
                abort(422)

        else:
            question = body.get('question', None)
            answer = body.get('answer', None)
            difficulty = body.get('difficulty', None)
            category = body.get('category', None)

            for value in (question, answer, difficulty, category):
                if not value:
                    print(value)
                    return manage_error_400(
                        f'Ooops! You\'ve Null or invalid syntax in your request data: {value}')

            try:
                new_question = Question(
                    question,
                    answer,
                    category,
                    difficulty
                )

                new_question.insert()

                return jsonify({
                    'success': True,
                    'message': 'created',
                    'question': new_question.format()
                }), 201

            except Exception as ex:
                print(ex)
                abort(422)

    @app.route('/categories/<category_id>/questions')
    def fetch_questions_by_id(category_id):
        manage_path_parameters_validation(category_id)

        try:
            schemed_questions = collect_questions_and_filter_by_category(
                category_id)
            paginated_questions = paginate_outcome(schemed_questions)

            return jsonify({
                'success': True,
                'questions': paginated_questions,
                'total_questions': len(schemed_questions),
                'current_category': category_id
            })

        except Exception as EXP:
            print(EXP)
            abort(422)

    @app.route('/tests', methods=['POST'])
    def test_questions():
        body = request.get_json()

        if not body:
            abort(500)

        else:
            previous_questions = body.get('previous_questions', None)
            test_category = body.get('test_category', None)

            try:
                questions = None
                selected_question = None

                if bool(int(test_category)):
                    questions = collect_questions_and_filter_by_category(
                        test_category)

                else:
                    questions = collect_questions()

                available_questions = [
                    question for question in questions if question.get(
                        'id') not in previous_questions]

                selected_question = random.choice(
                    available_questions) if len(available_questions) else None

                return jsonify({
                    'success': True,
                    'question': selected_question,
                    'available_questions': available_questions
                })

            except Exception as EXP:
                print(EXP)
                abort(422)

    '''
    @TODO:
    Create error handlers for all expected errors
    including 404 and 422.
    '''
    @app.errorhandler(400)
    def manage_error_400(error):
        return jsonify({
            'success': False,
            'error': 400,
            'message': 'Ooops! You\'ve Null or invalid syntax in request.'
        }), 400

    @app.errorhandler(404)
    def manage_error_404(error):
        return jsonify({
            'success': False,
            'error': 404,
            'message': "Ooops! Page not found"
        }), 404

    @app.errorhandler(405)
    def manage_error_405(error):
        return jsonify({
            'success': False,
            'error': 405,
            'message': "Ooops! This Method is not allowed"
        }), 405

    @app.errorhandler(422)
    def manage_error_422(error):
        return jsonify({
            'success': False,
            'error': 422,
            'message': "Ooops! Your request cannot be processed!"
        }), 422

    @app.errorhandler(500)
    def manage_error_500(error):
        return jsonify({
            'success': False,
            'error': 500,
            'message': "Ooops! There's an internal server error!"
        }), 500

    return app